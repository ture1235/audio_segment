"""Lightweight CNN model for multi-label alarm sound classification."""

import torch
import torch.nn as nn


def _conv_block(in_ch: int, out_ch: int, pool: bool = True) -> nn.Sequential:
    layers = [
        nn.Conv2d(in_ch, out_ch, kernel_size=3, padding=1, bias=False),
        nn.BatchNorm2d(out_ch),
        nn.ReLU(inplace=True),
    ]
    if pool:
        layers.append(nn.MaxPool2d(2))
    return nn.Sequential(*layers)


class AlarmClassifier(nn.Module):
    """CNN multi-label classifier operating on mel-spectrograms.

    Input:  [B, 1, N_MELS, T]
    Output: [B, NUM_CLASSES] — raw logits (use BCEWithLogitsLoss).
    """

    def __init__(self, num_classes: int):
        super().__init__()
        self.conv1 = _conv_block(1, 32)
        self.conv2 = _conv_block(32, 64)
        self.conv3 = _conv_block(64, 128)
        self.conv4 = _conv_block(128, 128, pool=False)

        self.global_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.classifier = nn.Sequential(
            nn.Flatten(),
            nn.Linear(128, 64),
            nn.ReLU(inplace=True),
            nn.Dropout(0.3),
            nn.Linear(64, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.conv3(x)
        x = self.conv4(x)
        x = self.global_pool(x)
        return self.classifier(x)

    def predict(self, x: torch.Tensor, threshold: float = 0.5) -> torch.Tensor:
        """Return binary predictions at the given threshold."""
        with torch.no_grad():
            logits = self.forward(x)
            probs = torch.sigmoid(logits)
            return (probs >= threshold).int()
