"""Training script for the multi-label alarm classifier."""

import os
import sys
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from sklearn.metrics import (
    f1_score,
    precision_score,
    recall_score,
    classification_report,
)
from tqdm import tqdm

from .config import (
    MODEL_PATH,
    MODEL_DIR,
    BATCH_SIZE,
    LEARNING_RATE,
    WEIGHT_DECAY,
    EPOCHS,
    EARLY_STOPPING_PATIENCE,
    TRAIN_SAMPLES_PER_EPOCH,
    VAL_SAMPLES,
)
from .data_loader import load_alarms, load_noise
from .dataset import AlarmDataset
from .model import AlarmClassifier


def _evaluate(
    model: nn.Module,
    dataloader: DataLoader,
    device: torch.device,
    threshold: float = 0.5,
) -> dict:
    """Compute per-class and overall metrics on a validation set."""
    model.eval()
    all_preds = []
    all_labels = []

    for batch_x, batch_y in dataloader:
        batch_x = batch_x.to(device)
        with torch.no_grad():
            logits = model(batch_x)
            probs = torch.sigmoid(logits)
            preds = (probs >= threshold).int().cpu().numpy()
        all_preds.append(preds)
        all_labels.append(batch_y.numpy())

    y_pred = np.concatenate(all_preds, axis=0)
    y_true = np.concatenate(all_labels, axis=0)

    micro_f1 = f1_score(y_true, y_pred, average="micro", zero_division=0)
    macro_f1 = f1_score(y_true, y_pred, average="macro", zero_division=0)
    per_class_f1 = f1_score(y_true, y_pred, average=None, zero_division=0)

    return {
        "micro_f1": micro_f1,
        "macro_f1": macro_f1,
        "per_class_f1": per_class_f1,
        "y_true": y_true,
        "y_pred": y_pred,
    }


def train(alarm_dir: str | None = None, noise_dir: str | None = None):
    """Run the full training pipeline.

    All alarm types appear in both training and validation (sample-level
    split via on-the-fly synthetic generation).  This is the correct
    approach when you have few base samples per class.
    """
    # --- Load data ---
    print("[1/3] Loading alarm and noise files...")
    alarms, alarm_names = load_alarms()
    noise_list = load_noise()

    num_alarms = len(alarms)
    if num_alarms == 0:
        print("ERROR: No alarm files loaded. Check data/alarms/")
        sys.exit(1)
    print(f"  Loaded {num_alarms} alarm types, {len(noise_list)} noise file(s)")
    for i, name in enumerate(alarm_names):
        duration = len(alarms[i]) / 22050
        print(f"    [{i}] {name:20s} ({duration:.1f}s)")

    # --- DataLoaders ---
    # Both train and val use all alarm types — synthetic generation
    # ensures different samples each epoch.
    print(f"\n[2/3] Building dataloaders "
          f"(train={TRAIN_SAMPLES_PER_EPOCH}, val={VAL_SAMPLES})...")
    train_ds = AlarmDataset(
        alarms, noise_list, num_alarms,
        alarm_indices=None,
        length=TRAIN_SAMPLES_PER_EPOCH,
    )
    val_ds = AlarmDataset(
        alarms, noise_list, num_alarms,
        alarm_indices=None,
        length=VAL_SAMPLES,
    )
    train_loader = DataLoader(train_ds, batch_size=BATCH_SIZE, shuffle=True,
                              num_workers=0, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=BATCH_SIZE, shuffle=False,
                            num_workers=0, pin_memory=True)

    # --- Model ---
    device = torch.device("cpu")
    print(f"\n[3/3] Building model (device: {device})...")
    model = AlarmClassifier(num_classes=num_alarms).to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"  Parameters: {n_params:,}")

    optimizer = torch.optim.Adam(
        model.parameters(), lr=LEARNING_RATE, weight_decay=WEIGHT_DECAY
    )
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", factor=0.5, patience=5
    )
    criterion = nn.BCEWithLogitsLoss()

    # --- Training loop ---
    print(f"\nTraining ({EPOCHS} epochs max, patience={EARLY_STOPPING_PATIENCE})...")
    best_val_f1 = 0.0
    best_epoch = 0
    patience_counter = 0
    os.makedirs(MODEL_DIR, exist_ok=True)

    for epoch in range(1, EPOCHS + 1):
        model.train()
        total_loss = 0.0
        pbar = tqdm(train_loader, desc=f"Epoch {epoch:3d}/{EPOCHS}", unit="batch")
        for batch_x, batch_y in pbar:
            batch_x, batch_y = batch_x.to(device), batch_y.to(device)
            optimizer.zero_grad()
            logits = model(batch_x)
            loss = criterion(logits, batch_y)
            loss.backward()
            optimizer.step()
            total_loss += loss.item()
            pbar.set_postfix(loss=f"{loss.item():.4f}")

        avg_loss = total_loss / len(train_loader)
        scheduler.step(avg_loss)

        # Validation
        metrics = _evaluate(model, val_loader, device)
        val_f1 = metrics["macro_f1"]

        print(
            f"  Epoch {epoch:3d} | loss={avg_loss:.4f} | "
            f"val_macro_f1={val_f1:.4f} | val_micro_f1={metrics['micro_f1']:.4f}"
        )

        # Per-class F1
        per_class = metrics["per_class_f1"]
        for i in range(len(per_class)):
            print(f"    [{i}] {alarm_names[i]:20s} F1={per_class[i]:.3f}")

        # Early stopping
        if val_f1 > best_val_f1:
            best_val_f1 = val_f1
            best_epoch = epoch
            patience_counter = 0
            torch.save(
                {
                    "epoch": epoch,
                    "model_state_dict": model.state_dict(),
                    "alarm_names": alarm_names,
                    "val_f1": val_f1,
                },
                MODEL_PATH,
            )
            print(f"  -> Best model saved (macro_f1={val_f1:.4f})")
        else:
            patience_counter += 1
            if patience_counter >= EARLY_STOPPING_PATIENCE:
                print(f"\n  Early stopping at epoch {epoch}")
                break

    print(f"\nTraining complete. Best epoch: {best_epoch}, best macro_f1: {best_val_f1:.4f}")
    print(f"Model saved to: {MODEL_PATH}")

    # Final evaluation report
    print("\n--- Classification Report (threshold=0.5) ---")
    checkpoint = torch.load(MODEL_PATH, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    final_metrics = _evaluate(model, val_loader, device)
    print(
        classification_report(
            final_metrics["y_true"],
            final_metrics["y_pred"],
            target_names=alarm_names,
            zero_division=0,
        )
    )
    return model, alarm_names


if __name__ == "__main__":
    train()
