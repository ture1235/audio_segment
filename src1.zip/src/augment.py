"""Synthetic training data generation via audio mixing.

Generates infinite training samples by mixing:
  - noise only       (15%)  -- negative samples with no active alarms
  - 1 alarm + noise  (30%)
  - 2 alarms + noise (35%)
  - 3 alarms + noise (20%)

Multi-alarm samples prepare the model for overlapping-alarm inference.
Noise-only samples let the model learn that silence/background has no alarms.
"""

import numpy as np

from .config import (
    N_SAMPLES,
    MIN_SNR_DB,
    MAX_SNR_DB,
    NO_ALARM_PROB,
    SINGLE_ALARM_PROB,
    DUAL_ALARM_PROB,
    TRIPLE_ALARM_PROB,
    DUAL_VOLUME_RATIO,
)
from .data_loader import extract_segment


def _snr_mix(signal: np.ndarray, noise_seg: np.ndarray, snr_db: float) -> np.ndarray:
    """Mix signal and noise at the given SNR (dB)."""
    sig_power = np.mean(signal**2)
    noise_power = np.mean(noise_seg**2)
    if noise_power < 1e-10:
        return signal
    desired_noise_power = sig_power / (10 ** (snr_db / 10))
    scale = np.sqrt(desired_noise_power / noise_power)
    return signal + noise_seg * scale


def _pick_alarms(
    candidates: list[int],
    count: int,
) -> list[int]:
    """Pick *count* distinct alarm indices from candidates."""
    if count > len(candidates):
        count = len(candidates)
    chosen = list(np.random.choice(candidates, size=count, replace=False))
    return [int(c) for c in chosen]


def _pick_audio(pool) -> np.ndarray:
    """Return a random audio array from *pool* (single array or list)."""
    if isinstance(pool, list):
        return pool[np.random.randint(len(pool))]
    return pool


def generate_sample(
    alarms: dict,
    noise_list: list,
    alarm_indices: list[int] | None = None,
) -> tuple[np.ndarray, np.ndarray]:
    """Generate one synthetic training sample.

    Args:
        alarms: dict[int, np.ndarray | list[np.ndarray]]
                  alarm_index -> single audio or list of audio variants
        noise_list: list[np.ndarray]    noise audio arrays
        alarm_indices: optional list of allowed alarm indices.
                       If None, all alarms are candidates.

    Returns:
        audio: np.ndarray of shape (N_SAMPLES,), float32
        label: np.ndarray of shape (num_classes,), float32 multi-hot vector
    """
    num_classes = len(alarms)

    if alarm_indices is None:
        candidates = list(alarms.keys())
    else:
        candidates = [i for i in alarm_indices if i in alarms]

    if len(candidates) < 1:
        raise ValueError("No alarm candidates available for sample generation.")

    # Decide how many alarms to mix (0, 1, 2, or 3)
    r = np.random.random()
    if r < NO_ALARM_PROB:
        num_alarms = 0
    elif r < NO_ALARM_PROB + SINGLE_ALARM_PROB:
        num_alarms = 1
    elif r < NO_ALARM_PROB + SINGLE_ALARM_PROB + DUAL_ALARM_PROB:
        num_alarms = 2
    else:
        num_alarms = 3

    # Build multi-hot label and mixed audio
    label = np.zeros(num_classes, dtype=np.float32)

    if num_alarms == 0:
        # Noise-only negative sample — all labels are 0
        noise_idx = np.random.randint(0, len(noise_list))
        audio = extract_segment(noise_list[noise_idx], N_SAMPLES)
        peak = np.max(np.abs(audio))
        if peak > 0:
            audio = audio / peak
        return audio.astype(np.float32), label

    # If we don't have enough candidates, downgrade
    num_alarms = min(num_alarms, len(candidates))

    # Pick alarms
    chosen = _pick_alarms(candidates, num_alarms)

    mixed = np.zeros(N_SAMPLES, dtype=np.float32)

    for rank, idx in enumerate(chosen):
        seg = extract_segment(_pick_audio(alarms[idx]), N_SAMPLES)
        if rank == 0:
            mixed = seg.copy()
        else:
            vol_ratio = np.random.uniform(*DUAL_VOLUME_RATIO)
            mixed = mixed + seg * vol_ratio
        label[idx] = 1.0

    # Mix with noise at random SNR
    noise_idx = np.random.randint(0, len(noise_list))
    noise_seg = extract_segment(noise_list[noise_idx], N_SAMPLES)
    snr_db = np.random.uniform(MIN_SNR_DB, MAX_SNR_DB)
    audio = _snr_mix(mixed, noise_seg, snr_db)

    # Final peak normalization
    peak = np.max(np.abs(audio))
    if peak > 0:
        audio = audio / peak

    return audio.astype(np.float32), label
